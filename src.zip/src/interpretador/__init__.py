"""Pacote interpretador"""
