"""Pacote simulador"""
