"""Pacote simulador.processador"""
